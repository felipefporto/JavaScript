// funções - functions

// como declarar
// deve ser declarada usando a palavra function seguida de "()" e "{}"
/* function funcao() {
    console.log('mensagem de uma função');
}

// chamando a função
funcao(); */

/* 
// função com parâmetros
// definindo parâmetros
function mensagem(primeiro, segundo) {
    console.log(primeiro, segundo)
}

// chamando a função atribuindo valor aos parâmetros
mensagem('Tudo certo', 'jovem!'); */